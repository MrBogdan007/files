$(document).ready(function() {

// --------------------------------- ТАБЫ - НАЧАЛО ---------------------------------
    $('.tab_content').find('div:not(:first)').hide();
    $('.tabs .tab').click(function(event) {
    	event.preventDefault();
    	var $this = $(this);
    	var $this_parent = $(this).parent();
        $this_parent.next().children('.tab_item').hide();
        $this_parent.children().removeClass("active");
        $this.addClass('active');

        var clicked = $this.attr('href');
        $('.tab_content ' + clicked).fadeIn('fast');
    });
// --------------------------------- ТАБЫ - КОНЕЦ ---------------------------------


    $.stellar({
    	responsive: true
    }); // --------------------------------- Паралакс ---------------------------------


     $(".carousel").owlCarousel({
     	loop: true,
     	navText: ['<div class="prev_arrow"></div>','<div class="next_arrow"><div>'],
     	navContainer: '.carousel',
     	responsive: {
     		0 : {
     			items: 1,
     			nav: true
     		}
     	}
     }); // --------------------------------- Карусель ---------------------------------

     $('.popup').magnificPopup({type:'image'});
     $('.popup_f').magnificPopup({
     	type: 'inline'
     }); // --------------------------------- Попап ---------------------------------

     $('form').submit(function(){
     	$(this).trigger('reset');
     	return false;
     }); // --------------------------------- Не отправляем и очищаем форму (для демо) ---------------------------------
});

$(window).load(function(){
	// --------------------------------- Анимация ---------------------------------
	var $header = $('header');
	$header.find('h1, h2').animated('fadeInDown','fadeOut');
	$header.find('.tabs_header').animated('fadeInLeft','fadeOut');
	$('.prof_item').animated('fadeInRight','fadeOut');
	$('#visible_form').animated('zoomInRight', 'fadeOut');
	$('.s_back h3').animated('fadeInUp', 'fadeOut');
	$('footer').animated('fadeInUp', 'fadeOut');

	// --------------------------------- Загрузчик в начале ---------------------------------
    $(".loader_inner").fadeOut();
    $(".loader").delay(400).fadeOut("slow");

});